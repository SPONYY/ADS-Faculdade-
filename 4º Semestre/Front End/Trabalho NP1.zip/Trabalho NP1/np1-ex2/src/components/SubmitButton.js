// Importa o React da biblioteca 'react'
import React from 'react';

// Importa o arquivo CSS 'SubmitButton.css' para estilização do botão
// Este arquivo é opcional e pode ser usado para definir estilos específicos para o botão de submissão
import './SubmitButton.css';

// Define o componente funcional 'SubmitButton' que recebe uma prop 'label'
const SubmitButton = ({ label }) => {
  return (
    // Renderiza um elemento <button> com o tipo 'submit' e a classe 'submit-button'
    // O tipo 'submit' faz com que este botão envie o formulário quando clicado
    <button type="submit" className="submit-button">
      {/* Exibe o texto do botão, que é passado como a prop 'label' */}
      {label}
    </button>
  );
};

// Exporta o componente 'SubmitButton' para ser utilizado em outros componentes
export default SubmitButton;
